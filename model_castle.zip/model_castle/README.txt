
These images/dataset are provided by Center for Machine Perception,
Czech Technical University in Prague. They can be freely used and
re-distributed for a non-commercial purpose. Commercial use requires a
licence. Any published results must acknowledge CMP as the source.

(c) Jana Kostliva, CMP CTU in Prague, 2007
 